﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Ap_escuela
{
    class AlumnoDAL
    {

       public static int AgregarAlumno(Alumno pAlumno)
       {
           int retorno = 0;
           using (SqlConnection Conn = BDComun.ObtnerCOnexion())
           { 
           SqlCommand Comando=new SqlCommand(string.Format("Insert Into Alumnos (Nombre, Apellido, Direccion, Fecha_nacimiento, id_curso) values ('{0}', '{1}','{2}','{3}','{4}')",
               pAlumno.Nombre, pAlumno.Apellido, pAlumno.Direccion, pAlumno.Fecha_Nac, pAlumno.IdCurso),Conn);

           retorno = Comando.ExecuteNonQuery();
           Conn.Close();
           
           }
           return retorno;       
       }

        public static int ModificarAlumno(Alumno pAlumno)
        {
            int retorno = 0;
            using (SqlConnection Conn = BDComun.ObtnerCOnexion())
            {
                string str = string.Format("Update Alumnos Set Nombre='{0}', Apellido='{1}', Direccion='{2}', Fecha_nacimiento='{3}', id_curso={4} where id={5}",
                    pAlumno.Nombre, pAlumno.Apellido, pAlumno.Direccion, pAlumno.Fecha_Nac, pAlumno.IdCurso, pAlumno.Id);

                SqlCommand Comando = new SqlCommand(str, Conn);

                retorno = Comando.ExecuteNonQuery();
                Conn.Close();

            }
            return retorno;
        }


        public static List<Alumno> BuscarAlumnos(String pNombre, String pApellido, bool exacto = false)
       {

           List<Alumno> Lista = new List<Alumno>();

           using (SqlConnection conexion = BDComun.ObtnerCOnexion())
           {
                string qry = string.Format("Select Id, Nombre,  Apellido, Direccion, Fecha_nacimiento from Alumnos where Nombre like '%{0}%' and Apellido like '%{1}%'", pNombre, pApellido);

                if (exacto == true)
                    qry = string.Format("Select Id, Nombre,  Apellido, Direccion, Fecha_nacimiento from Alumnos where Nombre='{0}' and Apellido='{1}'", pNombre, pApellido);

               SqlCommand comando = new SqlCommand(qry, conexion);

               SqlDataReader reader = comando.ExecuteReader();

               while (reader.Read())
               {
                   Alumno pAlumno = new Alumno();
                   pAlumno.Id = reader.GetInt32(0);
                   pAlumno.Nombre = reader.GetString(1);
                   pAlumno.Apellido = reader.GetString(2);
                   pAlumno.Direccion = reader.GetString(3);
                   pAlumno.Fecha_Nac = Convert.ToString(reader.GetDateTime(4));

                   Lista.Add(pAlumno);

               }
               conexion.Close();
               return Lista;

           }

       }

        public static List<Alumno> ListarAlumnosCurso(int pCurso)
        {

            List<Alumno> Lista = new List<Alumno>();

            using (SqlConnection conexion = BDComun.ObtnerCOnexion())
            {
                string qry = string.Format("Select Id, Nombre,  Apellido, Direccion, Fecha_nacimiento, id_curso from Alumnos where id_curso='{0}'", pCurso);

                SqlCommand comando = new SqlCommand(qry, conexion);

                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Alumno pAlumno = new Alumno();
                    pAlumno.Id = reader.GetInt32(0);
                    pAlumno.Nombre = reader.GetString(1);
                    pAlumno.Apellido = reader.GetString(2);
                    pAlumno.Direccion = reader.GetString(3);
                    pAlumno.Fecha_Nac = Convert.ToString(reader.GetDateTime(4));
                    pAlumno.IdCurso = reader.GetInt32(5);

                    Lista.Add(pAlumno);

                }
                conexion.Close();
                return Lista;

            }

        }



        public static Alumno ObtenerAlumno(Int64 pId)
       {

           using (SqlConnection conexion = BDComun.ObtnerCOnexion())
           {

               Alumno pAlumno = new Alumno();
               SqlCommand comando = new SqlCommand(string.Format(
                   "Select Id, Nombre,  Apellido, Direccion, Fecha_nacimiento from Alumnos where Id={0}",pId), conexion);

               SqlDataReader reader = comando.ExecuteReader();

               while (reader.Read())
               {
                   pAlumno.Id = reader.GetInt64(0);
                   pAlumno.Nombre = reader.GetString(1);
                   pAlumno.Apellido = reader.GetString(2);
                   pAlumno.Direccion = reader.GetString(3);
                   pAlumno.Fecha_Nac = Convert.ToString(reader.GetDateTime(4));

                   

               }
               conexion.Close();
               return pAlumno;

           }

       }



       public static int Modificar(Alumno pAlumno)
       {
           int retorno = 0;
           using (SqlConnection conexion = BDComun.ObtnerCOnexion())
           {
               SqlCommand comando = new SqlCommand(string.Format("Update Alumnos set Nombre='{0}', Apellido='{1}', Direccion='{2}', Fecha_Nacimiento='{3}' where Id={4}",
                   pAlumno.Nombre, pAlumno.Apellido, pAlumno.Direccion, pAlumno.Fecha_Nac, pAlumno.Id), conexion);

               retorno = comando.ExecuteNonQuery();
               conexion.Close();
           }
           return retorno;
       
       }


       public static int Eliminar(Int64 pId)
       {
           int retorno = 0;
           using (SqlConnection conexion = BDComun.ObtnerCOnexion())
           {

               SqlCommand comando = new SqlCommand(string.Format("Delete from Alumnos where Id={0}", pId), conexion);
               retorno = comando.ExecuteNonQuery();
               conexion.Close();
           }
           return retorno;
       
       }

    }
}
