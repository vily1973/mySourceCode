﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ap_escuela
{
  public  class Asignatura
    {

        // metodos
      public Int64 Id { get; set; }
      public String Nombre { get; set; }

      public Asignatura() { }

      public Asignatura(Int64 pId, String pNombre)

      {
          this.Id = pId;
          this.Nombre = pNombre;
      }
    }
}
