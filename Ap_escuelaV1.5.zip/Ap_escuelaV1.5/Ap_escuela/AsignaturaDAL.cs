﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Ap_escuela
{
    class AsignaturaDAL
    {

        public static List<String> ListarAsignaturas()
        {

            List<String> Lista = new List<String>();

            using (SqlConnection conexion = BDComun.ObtnerCOnexion())
            {
                string qry = string.Format("Select id, Nombre from Asignaturas");

                SqlCommand comando = new SqlCommand(qry, conexion);

                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Curso pAsignatura = new Curso();
                    pAsignatura.Id = reader.GetInt32(0);
                    pAsignatura.Nombre = reader.GetString(1);

                    Lista.Add(pAsignatura.Nombre);

                }
                conexion.Close();
                return Lista;

            }

        }

        public static int GetIdAsignatura(int SelectedIndex)
        {
            int ret = -1;

            using (SqlConnection conexion = BDComun.ObtnerCOnexion())
            {
                string qry = string.Format("Select id, Nombre from Asignaturas");

                SqlCommand comando = new SqlCommand(qry, conexion);

                SqlDataReader reader = comando.ExecuteReader();

                int pos = 0;

                while (reader.Read())
                {
                    if (pos == SelectedIndex)
                    {
                        ret = reader.GetInt32(0);
                        break;
                    }

                    pos++;
                }
                conexion.Close();
                return ret;

            }

        }

    }
}
