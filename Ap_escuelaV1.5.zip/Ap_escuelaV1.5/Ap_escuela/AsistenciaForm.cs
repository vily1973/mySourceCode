﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ap_escuela
{
    public partial class AsistenciaForm : Form
    {
        public AsistenciaForm()
        {
            InitializeComponent();
        }

        public Alumno AlumnoSeleccionado { get; set; }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Clear();

            int curso = CursoDAL.GetIdCurso(comboBox1.SelectedIndex);
            int ramo = AsignaturaDAL.GetIdAsignatura(comboBox2.SelectedIndex);

            if (curso > 0 && ramo > 0)
            {
                dataGridView1.DataSource = AsistenciaDAL.BuscarAsistencia(curso, ramo);

                for (int cnt = 1; cnt < 10; cnt++)
                { 
                    DataGridViewCheckBoxColumn dgvCmb = new DataGridViewCheckBoxColumn();
                    dgvCmb.ValueType = typeof(bool);
                    dgvCmb.Name = "Chk" + cnt;
                    dgvCmb.HeaderText = "Clase " + cnt;
                    dgvCmb.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

                    dataGridView1.Columns.Add(dgvCmb);

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        row.Cells[dgvCmb.Name].Value = true;
                    }
                }

            }

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void AsistenciaForm_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = CursoDAL.ListarCursos();
            comboBox2.DataSource = AsignaturaDAL.ListarAsignaturas();
        }

    }
}
