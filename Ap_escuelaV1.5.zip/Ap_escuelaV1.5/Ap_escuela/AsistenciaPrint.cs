﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ap_escuela
{
    public class AsistenciaPrint
    {

        // metodos
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        //public String Porcentaje { get; set; }
        public List<CheckBox> checkBoxes { get; set; } = new List<CheckBox>();


        public AsistenciaPrint()
        {
        }

        public AsistenciaPrint(String pNombre, String pApellido, String pPorcentaje, List<CheckBox> lcheckBoxes)
        {
            this.Nombre = pNombre;
            this.Apellido = pApellido;
            //this.Porcentaje = pPorcentaje;

            for (int cnt = 0; cnt < lcheckBoxes.Count; cnt++)
                this.checkBoxes.Add(lcheckBoxes[cnt]);

        }

    }
}
