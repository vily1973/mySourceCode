﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ap_escuela
{
    public class Asistencia
    {

        // metodos
        public Int64 Id { get; set; }
        public Int64 Id_Alumno { get; set; }
        public Int64 Id_Asignatura { get; set; }
        public String Porcentaje { get; set; }
        public float Factor { get; set; }

        public Asistencia()
        {
        }

        public Asistencia(Int64 pId, Int64 pId_Alumno, Int64 pId_Asignatura, String pPorcentaje, float Factor)
        {
            this.Id = pId;
            this.Id_Alumno = pId_Alumno;
            this.Id_Asignatura = pId_Asignatura;
            this.Porcentaje = pPorcentaje;
            this.Factor = Factor;
        }

    }
}
