﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Ap_escuela
{
    class CursoDAL
    {

        public static List<String> ListarCursos()
        {

            List<String> Lista = new List<String>();

            using (SqlConnection conexion = BDComun.ObtnerCOnexion())
            {
                string qry = string.Format("Select id, Nombre from Cursos");

                SqlCommand comando = new SqlCommand(qry, conexion);

                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Curso pCurso = new Curso();
                    pCurso.Id = reader.GetInt32(0);
                    pCurso.Nombre = reader.GetString(1);

                    Lista.Add(pCurso.Nombre);

                }
                conexion.Close();
                return Lista;

            }

        }

        public static int GetIdCurso(int SelectedIndex)
        {
            int ret = -1;

            using (SqlConnection conexion = BDComun.ObtnerCOnexion())
            {
                string qry = string.Format("Select id, Nombre from Cursos");

                SqlCommand comando = new SqlCommand(qry, conexion);

                SqlDataReader reader = comando.ExecuteReader();

                int pos = 0;

                while (reader.Read())
                {
                    if (pos == SelectedIndex)
                    {
                        ret = reader.GetInt32(0);
                        break;
                    }

                    pos++;
                }
                conexion.Close();
                return ret;

            }

        }


    }
}
