﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ap_escuela
{
  public  class Curso
    {

        // metodos
      public Int64 Id { get; set; }
      public String Nombre { get; set; }

      public Curso() { }

      public Curso(Int64 pId, String pNombre)

      {
          this.Id = pId;
          this.Nombre = pNombre;
      }
    }
}
