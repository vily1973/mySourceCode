﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Ap_escuela
{
    class AsistenciaDAL
    {

        public static List<AsistenciaPrint> BuscarAsistencia(int pCurso, int pRamo)
        {
            List<Alumno> listAlu = AlumnoDAL.ListarAlumnosCurso(pCurso);

            List<Asistencia> Lista = new List<Asistencia>();
            List<AsistenciaPrint> ListaPrint = new List<AsistenciaPrint>();

            foreach (var alu in listAlu)
            {
                long idCursoAlu = alu.IdCurso;

                if (idCursoAlu == pCurso)
                {
                    long idAlu = alu.Id;

                    using (SqlConnection conexion = BDComun.ObtnerCOnexion())
                    {
                        string qry = string.Format("Select id, id_alumno, id_asignatura, porcentaje, factor from Asistencia where id_alumno='{0}' and id_asignatura='{1}'", idAlu, pRamo);

                        SqlCommand comando = new SqlCommand(qry, conexion);

                        SqlDataReader reader = comando.ExecuteReader();

                        if (reader.Read())
                        {
                            Asistencia pAsistencia = new Asistencia();
                            pAsistencia.Id = reader.GetInt32(0);
                            pAsistencia.Id_Alumno = reader.GetInt32(1);
                            pAsistencia.Id_Asignatura = reader.GetInt32(2);
                            pAsistencia.Porcentaje = reader.GetString(3);

                            //pAsistencia.Factor = reader.GetInt32(4);

                            Lista.Add(pAsistencia);

                            AsistenciaPrint pAsistenciaPrint = new AsistenciaPrint();
                            pAsistenciaPrint.Nombre = alu.Nombre;
                            pAsistenciaPrint.Apellido = alu.Apellido;
                            //pAsistenciaPrint.Porcentaje = pAsistencia.Porcentaje;

                            ListaPrint.Add(pAsistenciaPrint);

                        }
                        else
                        {
                            AsistenciaPrint pAsistenciaPrint = new AsistenciaPrint();
                            pAsistenciaPrint.Nombre = alu.Nombre;
                            pAsistenciaPrint.Apellido = alu.Apellido;
                            //pAsistenciaPrint.Porcentaje = "No Informado";

                            ListaPrint.Add(pAsistenciaPrint);

                        }
                        conexion.Close();

                    }
                }
            }

            return ListaPrint;
        }


    }
}
